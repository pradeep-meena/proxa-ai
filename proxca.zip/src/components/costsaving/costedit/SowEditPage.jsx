import React from 'react'

function SowEditPage() {
  return (
    <div>
  
  <div className="row g-3">
  <div class="col">
    <input type="text" class="form-control" placeholder="Create New Sow " aria-label="Create sow"/>
  </div>
  <div className="col">
    <input type="text" class="form-control" placeholder="Request Team" aria-label="Request team"/>
  </div>
  <div className="col">
    <input type="text" class="form-control" placeholder="Service" aria-label="Service"/>
  </div>
  <div className="col">
    <input type="text" class="form-control" placeholder="Type Of Service" aria-label=" Type Of Service"/>
  </div>
</div>
    </div>
  )
}

export default SowEditPage
